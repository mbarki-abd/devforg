import { Plugin } from '@nocobase/server';
import path from 'path';
import { AgentGatewayClient } from './client';
import { AgentGatewayActions } from './actions';

export class PluginAgentGateway extends Plugin {
  private client!: AgentGatewayClient;

  async afterAdd() {
    // Plugin added
  }

  async beforeLoad() {
    // Before loading
  }

  async load() {
    // Load collections (agents)
    await this.db.import({
      directory: path.resolve(__dirname, 'collections'),
    });

    // Initialize the Agent API client
    const apiUrl = process.env.AGENT_API_URL || 'http://localhost:8080';
    const apiKey = process.env.AGENT_API_KEY || '';

    this.client = new AgentGatewayClient({
      url: apiUrl,
      apiKey,
    });

    // Register client as a service
    this.app.container.register('agentGateway', this.client);

    // Register custom actions
    const actions = new AgentGatewayActions(this.client, this.db);

    this.app.resourcer.define({
      name: 'agent-gateway',
      actions: {
        execute: actions.execute.bind(actions),
        status: actions.status.bind(actions),
        cancel: actions.cancel.bind(actions),
        health: actions.health.bind(actions),
      },
    });

    // Register ACL resources
    this.app.acl.registerSnippet({
      name: `pm.${this.name}`,
      actions: ['agents:*', 'agent-gateway:*'],
    });

    // Setup WebSocket relay for real-time updates
    this.setupWebSocketRelay();

    this.app.logger.info('Agent Gateway plugin loaded');
  }

  private setupWebSocketRelay() {
    // Listen for events from Agent API
    this.client.onEvent((event) => {
      // Broadcast to connected clients
      if (this.app.ws) {
        this.app.ws.broadcast(`execution:${event.executionId}`, event);
      }
    });
  }

  async install() {
    // Sync database schema
    await this.db.sync();
    this.app.logger.info('Agent Gateway plugin installed');
  }

  async afterEnable() {
    // After plugin is enabled
  }

  async afterDisable() {
    // After plugin is disabled
    this.client?.disconnect();
  }

  async remove() {
    // Plugin removal
    this.client?.disconnect();
  }
}

export default PluginAgentGateway;
